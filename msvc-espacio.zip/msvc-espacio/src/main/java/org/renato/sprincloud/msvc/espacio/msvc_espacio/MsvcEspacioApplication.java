package org.renato.sprincloud.msvc.espacio.msvc_espacio;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MsvcEspacioApplication {

	public static void main(String[] args) {
		SpringApplication.run(MsvcEspacioApplication.class, args);
	}

}
