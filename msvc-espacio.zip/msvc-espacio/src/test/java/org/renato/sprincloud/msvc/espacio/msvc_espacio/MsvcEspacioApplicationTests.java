package org.renato.sprincloud.msvc.espacio.msvc_espacio;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsvcEspacioApplicationTests {

	@Test
	void contextLoads() {
	}

}
